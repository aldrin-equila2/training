//
//  Fourth_DependentComponentPickerViewController.h
//  Chapter7_Part1
//
//  Created by Andvari Techstars on 2/21/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kStateComponent 0
#define kZipComponent 1

@interface Fourth_DependentComponentPickerViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>

@property (strong, nonatomic) IBOutlet UIPickerView * picker;
@property (strong, nonatomic) IBOutlet NSDictionary * stateZips;
@property (strong, nonatomic) IBOutlet NSArray * states;
@property (strong, nonatomic) IBOutlet NSArray * zips;

-(IBAction)btnPressed;

@end
