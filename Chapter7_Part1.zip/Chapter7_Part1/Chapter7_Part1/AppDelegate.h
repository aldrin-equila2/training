//
//  AppDelegate.h
//  Chapter7_Part1
//
//  Created by Andvari Techstars on 2/21/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "First_DatePickerViewController.h"
#import "Second_SingleComponentPickerViewController.h"
#import "Third_DoubleComponentPickerViewController.h"
#import "Fourth_DependentComponentPickerViewController.h"
#import "Fifth_CustomPickerViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) IBOutlet UITabBarController * rootController;

@end
