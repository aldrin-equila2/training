//
//  Third_DoubleComponentPickerViewController.h
//  Chapter7_Part1
//
//  Created by Andvari Techstars on 2/21/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kFillingComponent 0
#define kBreadComponent 1

@interface Third_DoubleComponentPickerViewController : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate>

@property (strong, nonatomic) IBOutlet UIPickerView * doublePicker;
@property (strong, nonatomic) IBOutlet NSArray * fillingTypes;
@property (strong, nonatomic) IBOutlet NSArray * breadTypes;

-(IBAction)buttonPressed;

@end
