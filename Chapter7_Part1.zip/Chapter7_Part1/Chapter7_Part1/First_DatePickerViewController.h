//
//  First_DatePickerViewController.h
//  Chapter7_Part1
//
//  Created by Andvari Techstars on 2/21/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface First_DatePickerViewController : UIViewController

@property(strong, nonatomic) IBOutlet UIDatePicker * datePicker;
-(IBAction)buttonPressed;

@end
