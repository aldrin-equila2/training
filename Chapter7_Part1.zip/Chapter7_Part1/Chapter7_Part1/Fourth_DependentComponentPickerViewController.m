//
//  Fourth_DependentComponentPickerViewController.m
//  Chapter7_Part1
//
//  Created by Andvari Techstars on 2/21/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "Fourth_DependentComponentPickerViewController.h"

@interface Fourth_DependentComponentPickerViewController ()

@end

@implementation Fourth_DependentComponentPickerViewController
@synthesize picker, states, zips, stateZips;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSBundle * bundle = [NSBundle mainBundle]; //reference to our main bundle
    
    //retrieves the URL of the resource "statedictionary". this returns the url of the statedictionary file in our supporting files
    NSURL * plistURL = [bundle URLForResource:@"statedictionary" withExtension:@"plist"];
    
    //all the contents of the statedictionary file will be loaded to the dictionary
    NSDictionary * dictionary = [NSDictionary dictionaryWithContentsOfURL:plistURL];
    
    //assigned dictionary to stateZips
    self.stateZips = dictionary;
    
    //getting all the keys to populate the array for the left hand component
    NSArray * components = [self.stateZips allKeys];
    //sorting it alphabetically
    NSArray * sorted = [components sortedArrayUsingSelector:@selector(compare:)];
    //assigning the sorted components to states
    self.states = sorted;
    
    //gets the object from the states array at index 0 (this will return the name of the state that will be selected at launch time
    NSString * selectedState = [self.states objectAtIndex:0];
    //we then use that state name to grab the array of ZIP codes for the state
    NSArray * array = [stateZips objectForKey:selectedState];
    //assigned zip codes for the state which will be used to feed the data
    self.zips = array;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)btnPressed{
    NSInteger stateRow = [picker selectedRowInComponent:kStateComponent];
    NSInteger zipRow = [picker selectedRowInComponent:kZipComponent];
    
    NSString * state = [self.states objectAtIndex:stateRow];
    NSString * zip = [self.zips objectAtIndex:zipRow];
    
    NSString * title = [[NSString alloc] initWithFormat:@"You selected zip code %@.", zip];
    NSString * msg = [[NSString alloc] initWithFormat:@"%@ is in %@", zip, state];
    
    
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (component == kStateComponent) return [self.states count];
    return [self.zips count];
}


#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == kStateComponent)
        return [self.states objectAtIndex:row];
    return [self.zips objectAtIndex:row];
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
       inComponent:(NSInteger)component { if (component == kStateComponent) {
    NSString *selectedState = [self.states objectAtIndex:row];
    NSArray *array = [stateZips objectForKey:selectedState];
    self.zips = array;
    [picker selectRow:0 inComponent:kZipComponent animated:YES];
    [picker reloadComponent:kZipComponent];
    }
}

//delegate method that indicate how wide each component should be(for the picker)
-(CGFloat) pickerView:(UIPickerView *) pickerView widthForComponent:(NSInteger) component{
    return 100; //the width of the first component (left)
    return 50; //the width of the second component (right)
}

@end
