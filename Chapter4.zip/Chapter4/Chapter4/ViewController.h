//
//  ViewController.h
//  Chapter4
//
//  Created by Andvari Techstars on 2/19/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIActionSheetDelegate>
{
    UITextField * txtName, *txtNumber;
    UIButton * btnDo;
    UISegmentedControl * segment;
    UILabel * sliderLabel;
    UISwitch * leftSwitch, * rightSwitch;
}

@property (nonatomic, retain) IBOutlet UITextField * txtName, * txtNumber;
@property (nonatomic, retain) IBOutlet UIButton * btnDo;
@property (nonatomic, retain) IBOutlet UISegmentedControl * segment;
@property (nonatomic, retain) IBOutlet UILabel * sliderLabel;
@property (nonatomic, retain) IBOutlet UISwitch * leftSwitch, * rightSwitch;

-(IBAction)backgroundTap:(id)sender;
-(IBAction)sliderChanged:(id)sender;
-(IBAction)switchChanged:(id)sender;
-(IBAction)toggleControls:(id)sender;

@end
