//
//  ViewController.m
//  Chapter4
//
//  Created by Andvari Techstars on 2/19/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txtName, txtNumber;
@synthesize btnDo;
@synthesize segment;
@synthesize sliderLabel;
@synthesize leftSwitch, rightSwitch;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bg.jpg"]];
    
    
    //Changing the background of the do something button when it is clicked
    UIImage *buttonImageNormal = [UIImage imageNamed:@"whiteButton.png"];
    UIImage *stretchableButtonImageNormal = [buttonImageNormal
                                             stretchableImageWithLeftCapWidth:12 topCapHeight:0];
    [btnDo setBackgroundImage:stretchableButtonImageNormal
                     forState:UIControlStateNormal];
    
    UIImage *buttonImagePressed = [UIImage imageNamed:@"blueButton.png"];
    UIImage *stretchableButtonImagePressed = [buttonImagePressed
                                              stretchableImageWithLeftCapWidth:12 topCapHeight:0];
    [btnDo setBackgroundImage:stretchableButtonImagePressed
                     forState:UIControlStateHighlighted];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//option 2 for removing the keyboard
/*-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [txtName resignFirstResponder];
    [txtNumber resignFirstResponder];
}*/

//if the button is pressed
//ui action sheet needs <UIActionSheetDelete> as the parameter in the .h file
-(IBAction)btnDo_M{
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
    initWithTitle:@"Are you sure?"
    delegate:self
    cancelButtonTitle:@"No Way!"
    destructiveButtonTitle:@"Yes, I’m Sure!"
    otherButtonTitles:nil];
    //otherButtonTitles:@"Foo",@"Bar",nil]; - for many buttons
    
    //showing the action sheet
    [actionSheet showInView:self.view];
}


//action for action sheet
- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != [actionSheet cancelButtonIndex]) {
        NSString *msg = nil;
        if (txtName.text.length > 0)
            msg = [[NSString alloc] initWithFormat: @"You can breathe easy, %@, everything went OK.", txtName.text];
        else
            msg = @"You can breathe easy, everything went OK.";
        
        //alert
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Something was done" message:msg delegate:self cancelButtonTitle:@"Phew!" otherButtonTitles:nil];
        [alert show];
    }
}

/*option 1 for removing the keyboard
//go to your identity inspector and change UIView to UIControl to give the view the ability to trigger action methods
//then tag use Touch Down and select backgroundTap*/
-(IBAction)backgroundTap:(id)sender{
    [txtName resignFirstResponder];
    [txtNumber resignFirstResponder];
}

-(IBAction)sliderChanged:(id)sender{
    UISlider * slider = (UISlider *) sender;
    int progressAsInt = (int) roundf(slider.value);
    sliderLabel.text = [NSString stringWithFormat:@"%d", progressAsInt];
}

-(IBAction)switchChanged:(id)sender{
    UISwitch *whichSwitch = (UISwitch *)sender;
    BOOL setting = whichSwitch.isOn;
    [leftSwitch setOn:setting animated:YES];
    [rightSwitch setOn:setting animated:YES];
}

-(IBAction)toggleControls:(id)sender{
    // 0 == switches index
    if ([sender selectedSegmentIndex] == 0) {
        leftSwitch.hidden = NO;
        rightSwitch.hidden = NO;
        btnDo.hidden = YES;
    }
    else {
        leftSwitch.hidden = YES;
        rightSwitch.hidden = YES;
        btnDo.hidden = NO;
    }
}

@end
