//
//  MoveMeController.h
//  Chapter9
//
//  Created by Andvari Techstars on 2/27/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "SecondLevelController.h"

@interface MoveMeController : SecondLevelController

//a mutable array to hold our data and keep track of the order of the rows. It must be mutable because we need to be able to move items around as we are notified of moves.
@property (strong, nonatomic) NSMutableArray * list;

-(IBAction)toogleMove;

@end
