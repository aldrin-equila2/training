//
//  DisclosureButtonController.h
//  Chapter9
//
//  Created by Andvari Techstars on 2/26/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "SecondLevelController.h"

@interface DisclosureButtonController : SecondLevelController

@property (strong, nonatomic) NSArray * list;

@end
