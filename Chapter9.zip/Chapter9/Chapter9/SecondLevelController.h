//
//  SecondLevelController.h
//  Chapter9
//
//  Created by Andvari Techstars on 2/26/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondLevelController : UITableViewController

@property (strong, nonatomic) UIImage * rowImage;

@end
