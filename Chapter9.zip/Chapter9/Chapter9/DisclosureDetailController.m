//
//  DisclosureDetailController.m
//  Chapter9
//
//  Created by Andvari Techstars on 2/26/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "DisclosureDetailController.h"

@interface DisclosureDetailController ()

@end

@implementation DisclosureDetailController
@synthesize label, message;

-(void)viewWillAppear:(BOOL)animated{
    label.text = message;
    [super viewWillAppear:animated];
}


//THIS IS THE ORIGINAL CONTENT WHEN IT IS FIRST CREATED

/*- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}*/

@end
