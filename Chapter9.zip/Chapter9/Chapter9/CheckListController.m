//
//  CheckListController.m
//  Chapter9
//
//  Created by Andvari Techstars on 2/26/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "CheckListController.h"

@interface CheckListController ()

@end

@implementation CheckListController
@synthesize list, lastIndexPath;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    NSArray *array = [[NSArray alloc] initWithObjects:@"Who Hash",
                      @"Bubba Gump Shrimp Étouffée", @"Who Pudding", @"Scooby Snacks", @"Everlasting Gobstopper", @"Green Eggs and Ham", @"Soylent Green", @"Hard Tack", @"Lembas Bread", @"Roast Beast", @"Blancmange", nil];
    self.list = array;
}




#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [list count];
}




-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * CheckMarkCellIdentifier = @"CheckMarkCellIdentifier";
    
    UITableViewCell * cell =[tableView dequeueReusableCellWithIdentifier:CheckMarkCellIdentifier];
    
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CheckMarkCellIdentifier];
    }
    
    //extracting the row from this cell and from the current selection
    NSUInteger row = [indexPath row];
    NSUInteger oldRow = [lastIndexPath row];
    
    //grabs the value for this row from our array and assign it to the cell's title
    cell.textLabel.text = [list objectAtIndex:row];
    
    //Then we set the accessory to show either a check mark or nothing, depending on whether the two rows are the same. In other words, if the table is requesting a cell for a row that is the currently selected row, we set the accessory icon to be a check mark; otherwise, we set it to be nothing. Notice that we also check lastIndexPath to make sure it’s not nil. We do this because a nil lastIndexPath indicates no selection. However, calling the row method on a nil object will return a 0, which is a valid row, but we don’t want to put a check mark on row 0 when, in reality, there is no selection.
    cell.accessoryType = (row == oldRow && lastIndexPath !=nil)?
    UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    
    return cell;
}


#pragma mark -
#pragma mark Table Delegate Methods
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //grabbing the row that was just selected and the row that was previously selected
    int newRow = [indexPath row];
    int oldRow = (lastIndexPath !=nil) ? [lastIndexPath row] : -1;
    
    //if the new row and old row are the same, we dont bother making any changes
    if (newRow != oldRow) {
        //grabbing the cell that was just selected
        UITableViewCell * newCell = [tableView cellForRowAtIndexPath:indexPath];
        //assigning a check mark for the cell that was just selected as its accessory icon
        newCell.accessoryType = UITableViewCellAccessoryCheckmark;
        
        //grabbing the previously selected cell
        UITableViewCell * oldCell = [tableView cellForRowAtIndexPath:lastIndexPath];
        //setting accessory icon of the previously selected cell to none
        oldCell.accessoryType = UITableViewCellAccessoryNone;
        lastIndexPath = indexPath;
    }
    else{}
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
