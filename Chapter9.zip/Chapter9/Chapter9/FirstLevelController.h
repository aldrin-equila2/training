//
//  FirstLevelController.h
//  Chapter9
//
//  Created by Andvari Techstars on 2/26/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstLevelController : UITableViewController

//this will hold the instances of the second-level view controllers. We’ll use it to feed data to our table.
@property (strong, nonatomic) NSArray * controllers;

@end
