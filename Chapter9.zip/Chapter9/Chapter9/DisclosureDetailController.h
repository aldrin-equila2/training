//
//  DisclosureDetailController.h
//  Chapter9
//
//  Created by Andvari Techstars on 2/26/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisclosureDetailController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel * label;
//The reason why we use copy (rather than strong or retain property) is that their may be potential existence of mutable strings.
@property (copy, nonatomic) NSString * message;
//As it turns out, sending copy to any immutable string instance doesn’t actually copy the string. Instead, it returns the same string object, after increasing its reference count.
@end
