//
//  MoveMeController.m
//  Chapter9
//
//  Created by Andvari Techstars on 2/27/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "MoveMeController.h"

@interface MoveMeController ()

@end

@implementation MoveMeController
@synthesize list;

//All that we’re doing here is toggling edit mode and then setting the button’s title to an appropriate value.
-(IBAction)toogleMove{
    [self.tableView setEditing:!self.tableView.editing animated:YES];
    
    if (self.tableView.editing)
        [self.navigationItem.rightBarButtonItem setTitle:@"Done"];
    else
        [self.navigationItem.rightBarButtonItem setTitle:@"Move"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    //It checks to see if list is nil, and if it is (meaning this is the first time this method has been called), it creates a mutable array filled with values, so our table has some data to show.
    if (list == nil) {
        NSMutableArray *array = [[NSMutableArray alloc]
                                 initWithObjects: @"Eeny", @"Meeny", @"Miney", @"Moe", @"Catch",
                                 @"A", @"Tiger", @"By", @"The", @"Toe", nil];
        self.list = array;
    }
    
    //we’re creating a button bar item, which is a button that will sit on the navigation bar. We give it a title of Move and specify a constant, UIBarButtonItemStyleBordered, to indicate that we want a standard bordered bar button.
    UIBarButtonItem *moveButton = [[UIBarButtonItem alloc] initWithTitle:@"Move"
            style:UIBarButtonItemStyleBordered target:self action:@selector(toogleMove)];
    
    self.navigationItem.rightBarButtonItem = moveButton;
}



#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section { return [list count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *MoveMeCellIdentifier = @"MoveMeCellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MoveMeCellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MoveMeCellIdentifier];
        cell.showsReorderControl = YES;
    }
    
    NSUInteger row = [indexPath row]; cell.textLabel.text = [list objectAtIndex:row];
    return cell;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}



//called when the user moves a row
-(void) tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *) fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath{
    
    //Retrieving the row that needs to be moved. then we retrieve the row's new position
    NSUInteger fromRow = [fromIndexPath row];
    NSUInteger toRow = [toIndexPath row];
    
    //We now need to remove the specified object from the array and reinsert it at its new location.
    id object = [list objectAtIndex:fromRow];
    [list removeObjectAtIndex:fromRow];
    
    //After we’ve removed it, we need to reinsert it into the specified new location.
    [list insertObject:object atIndex:toRow];
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
