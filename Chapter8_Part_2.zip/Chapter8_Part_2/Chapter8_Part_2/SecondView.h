//
//  SecondView.h
//  Chapter8_Part_2
//
//  Created by Andvari Techstars on 2/25/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondView : UITableViewCell

//Note that instead of declaring the NSString properties with strong semantics, we’re using copy. Doing so with NSString values is always a good idea, because there’s a risk that the string value passed in to a property setter may actually be an NSMutableString, which the sender can modify later on, leading to problems.
@property (copy, nonatomic) NSString * name;
@property (copy, nonatomic) NSString * color;

@end
