//
//  MainView.h
//  Chapter8_Part_2
//
//  Created by Andvari Techstars on 2/25/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainView : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (copy, nonatomic) NSArray * computers;

@end
