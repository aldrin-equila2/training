//
//  ViewController.h
//  Chapter5
//
//  Created by Andvari Techstars on 2/20/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(weak, nonatomic) IBOutlet UIButton * btnUL;
@property(weak, nonatomic) IBOutlet UIButton * btnUR;
@property(weak, nonatomic) IBOutlet UIButton * btnL;
@property(weak, nonatomic) IBOutlet UIButton * btnR;
@property(weak, nonatomic) IBOutlet UIButton * btnLL;
@property(weak, nonatomic) IBOutlet UIButton * btnLR;

@end
