//
//  ViewController.m
//  Chapter5
//
//  Created by Andvari Techstars on 2/20/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize btnL,btnLL,btnLR,btnR,btnUL,btnUR;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bg1_wood.jpg"]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//1. Orientation
//the 4 interface orientation
- (BOOL)shouldAutorotateToInterfaceOrientation: (UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

//2. AutoSizing is just enabling the auto resize in the size inspector..
//on your xib.. click on the elements to be resize then use the box in the Autosizing
//just position the red dashes


//3. This is called: "Restructure"
//this method is called automatically when the simulator has change orientation
- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)
interfaceOrientation duration:(NSTimeInterval)duration {
    if (UIInterfaceOrientationIsPortrait(interfaceOrientation)) {
        btnUL.frame = CGRectMake(20, 20, 125, 125);
        btnUR.frame = CGRectMake(175, 20, 125, 125);
        btnL.frame = CGRectMake(20, 168, 125, 125);
        btnR.frame = CGRectMake(175, 168, 125, 125);
        btnLL.frame = CGRectMake(20, 315, 125, 125);
        btnLR.frame = CGRectMake(175, 315, 125, 125);
    } else {
        btnUL.frame = CGRectMake(20, 20, 125, 125);
        btnUR.frame = CGRectMake(20, 155, 125, 125);
        btnL.frame = CGRectMake(177, 20, 125, 125);
        btnR.frame = CGRectMake(177, 155, 125, 125);
        btnLL.frame = CGRectMake(328, 20, 125, 125);
        btnLR.frame = CGRectMake(328, 155, 125, 125);
    }
}

@end
