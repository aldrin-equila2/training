//
//  ViewController.h
//  Chapter3
//
//  Created by Andvari Techstars on 2/19/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel * lblTitle;
    UIButton * btnLeft, * btnRight;
}

@property (retain, nonatomic) IBOutlet UILabel * lblTitle;
@property (retain, nonatomic) IBOutlet UIButton * btnLeft, * btnRight;

-(IBAction)btnLeftM;
-(IBAction)btnRightM;

@end
