//
//  ViewController.m
//  Chapter3
//
//  Created by Andvari Techstars on 2/19/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize btnLeft, btnRight, lblTitle;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bg.jpg"]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)btnLeftM{
    lblTitle.text = [NSString stringWithFormat:@"The Left Button is Clicked!"];
}

-(IBAction)btnRightM{
    lblTitle.text = @"The Right Button is Clicked!";
}

@end
