//
//  Main_ViewViewController.m
//  Chapter8_Part1
//
//  Created by Andvari Techstars on 2/24/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "Main_ViewViewController.h"

@interface Main_ViewViewController ()

@end

@implementation Main_ViewViewController
@synthesize tview;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //tview.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bg1_wood.jpg"]];
    
    NSArray *array = [[NSArray alloc] initWithObjects:@"Sleepy", @"Sneezy",
                      @"Bashful", @"Happy", @"Doc", @"Grumpy", @"Dopey", @"Thorin", @"Dorin", @"Nori", @"Ori", @"Balin", @"Dwalin", @"Fili", @"Kili", @"Oin", @"Gloin", @"Bifur", @"Bofur", @"Bombur", nil];
    self.listData = array;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark Table View Data Source Methods

//this method is called to ask how many rows are in a particular section
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.listData count];
}




//The first parameter, tableView, is a reference to the table doing the asking. This allows us to create classes that act as a data source for multiple tables.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //used as a key to represent
    static NSString *SimpleTableIdentifier = @"SimpleTableIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: SimpleTableIdentifier];
    
    if (cell == nil) {
        
        //UITableViewCellStyleDefault - just sets the cell's detail text (this doesnt make use of detail text
        //UITableViewCellStyleSubtitle - both text elements are shown, one below the other
        //UITableViewCellStyleValue1 - This style places the text label and detail text label on the same line on opposite sides of the cell.
        //UITableViewCellStyleValue2 - It doesn’t show the cell’s icon, but places the detail text label to the left of the text label. In this layout, the detail text label acts as a label describing the type of data held in the text label.
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:SimpleTableIdentifier];
    }
    
    UIImage *image = [UIImage imageNamed:@"star.png"];
    cell.imageView.image = image;
    
    //identifies w/c row the table view is asking
    NSUInteger row = [indexPath row];
    
    //use the row number of the table to get the corresponding string from the array
    cell.textLabel.text = [self.listData objectAtIndex:row];
    
    //to change the font of the tableview
    cell.textLabel.font = [UIFont boldSystemFontOfSize:50];
    
    //We use the string @"Mr. Disney" for the first seven rows and @"Mr. Tolkien" for the rest.
    if(row <7)
        cell.detailTextLabel.text = @"Mr. Disney";
    else
        cell.detailTextLabel.text = @"Mr. Tolkien";
    return cell;
}






//The table view delegate can specify the height of the table view’s rows. In fact, it can specify unique values for each row if you find that necessary.
//to tell the table view to set the row height for all rows to 70 pixels tall.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}






//This method sets the indent level for each row to its row number, so row 0 will have an indent level of 0, row 1 will have an indent level of 1, and so on. An indent level is simply an integer that tells the table view to move that row a little to the right. The higher the number, the further to the right the row will be indented.
#pragma mark -
#pragma mark Table Delegate Methods

- (NSInteger)tableView:(UITableView *)tableView indentationLevelForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSUInteger row = [indexPath row]; return row;
}




//==================Two delegate methods to determine if the user has selected a particular row==========================\\

//First method: is called before the row is selected and can be used to prevent the row from being selected, or even change which row gets selected.

//specifies that the first row is not selectable.
- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSUInteger row = [indexPath row];
    if (row == 0)//index of the first row
        return nil;//indicates that no rows shall be selected
    return indexPath;//returns the selected index path.. means its ok to select the row
}




//Second Method: delegate method that is called after a row has been selected, which is typically where you’ll actually handle the selection.

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSUInteger row = [indexPath row];
    NSString *rowValue = [self.listData objectAtIndex:row];
    NSString *message = [[NSString alloc] initWithFormat: @"You selected %@", rowValue];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Row Selected!"
                                                    message:message
                                                   delegate:nil cancelButtonTitle:@"Yes I Did"
                                          otherButtonTitles:nil]; [alert show];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
