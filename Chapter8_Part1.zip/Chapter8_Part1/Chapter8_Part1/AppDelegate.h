//
//  AppDelegate.h
//  Chapter8_Part1
//
//  Created by Andvari Techstars on 2/24/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Main_ViewViewController.h";
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong,nonatomic) Main_ViewViewController * main;

@end
