//
//  Main_ViewViewController.h
//  Chapter8_Part1
//
//  Created by Andvari Techstars on 2/24/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Main_ViewViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) NSArray *listData;
@property (retain, nonatomic) IBOutlet UITableView * tview;

@end
