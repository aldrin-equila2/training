//
//  MainView.m
//  Chapter8_Par_3
//
//  Created by Andvari Techstars on 2/25/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "MainView.h"
#import "NSDictionary+MutableDeepCopy.h"

@interface MainView ()

@end

@implementation MainView
//method synthesizers
@synthesize names, keys, table, search,allNames, isSearching;

#pragma mark -
#pragma mark Custom Methods
//called when the search is canceled or the search term changes
//all this method does is to create a mutable copy of allNames, assign it to names, and then refresh the keys so it includes all the letters of the alphabet
- (void)resetSearch {
    self.names = [self.allNames mutableDeepCopy];
    NSMutableArray *keyArray = [[NSMutableArray alloc] init];
    
    [keyArray addObject:UITableViewIndexSearch]; //adding the special value to the keys array
    
    [keyArray addObjectsFromArray:[[self.allNames allKeys]
                                   sortedArrayUsingSelector:@selector(compare:)]];
    self.keys = keyArray;
}



//Search Function
- (void)handleSearchForTerm:(NSString *)searchTerm {
    NSMutableArray *sectionsToRemove = [[NSMutableArray alloc] init]; //storing the sections to be removed in an array, and after alocating the array we remove all the objects at once
    [self resetSearch];
    
    //enumerating all the keys in the newly restored keys array
    for (NSString *key in self.keys) {
        NSMutableArray *array = [names valueForKey:key];
        NSMutableArray *toRemove = [[NSMutableArray alloc] init];
        
        //iterate through all the names in the current array. So, if we’re currently working through the key of A, this loop will enumerate through all the names that begin with A.
        for (NSString *name in array) {
            if ([name rangeOfString:searchTerm options:NSCaseInsensitiveSearch].location == NSNotFound){
                [toRemove addObject:name];
            }
            else{
                
            }
        }
        
        //checks to see whether the array of names to be removed is the same length as the array of names.
        if ([array count] == [toRemove count]){
            //adding it to the keys to be removed later
            [sectionsToRemove addObject:key];
        }
        else{
            
        }
        //remove the nonmatching names in the section's array
        [array removeObjectsInArray:toRemove];
    }
    
    [self.keys removeObjectsInArray:sectionsToRemove]; //removed the empty sections
    [table reloadData];//reload the tables data
}




- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //Loads the plist into the allNames dictionary
    NSString * path = [[NSBundle mainBundle] pathForResource:@"sortednames" ofType:@"plist"];
    NSDictionary * dict = [[NSDictionary alloc] initWithContentsOfFile:path];
    self.allNames = dict;
    [self resetSearch];
    
    [table reloadData];
    [table setContentOffset: CGPointMake(0.0, 44.0) animated:NO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark Table View Data Source Methods
//means one section in each key in our dictionary
-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return ([keys count] > 0) ? [keys count] : 1;
}





-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSString * key = [keys objectAtIndex:section];
    NSArray * nameSection = [names objectForKey:key];
    return [nameSection count];
}





-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
    
    NSString * key = [keys objectAtIndex:section];
    NSArray * nameSection = [names objectForKey:key];
    
    static NSString * SectionsTableIdentifier = @"SectionsTableIdentifier";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:SectionsTableIdentifier];
    
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:SectionsTableIdentifier];
    }
    else{
        
    }
    cell.textLabel.text = [nameSection objectAtIndex:row];
    return cell;
}





//allows you to specify an optional header value for each section, and we simply return the letter for this group.
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if([keys count] ==0){
        return nil;
    }
    else{}
    
    NSString *key = [keys objectAtIndex:section];
    
    //suppressing the section header
    if(key==UITableViewIndexSearch){
        return nil;
    }
    else{}
    
    return key;
}






//found in the right side (A-Z - vertical)
//indexing.. Note you must more than 1 sections to use the index and the entries of this arrays must correspond to those sections
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    if(isSearching){
        return nil;
    }else{}
    return keys;
}


//set isSearching to yes when the seaching begins
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
    [table reloadData];
}


#pragma mark -
#pragma mark Table View Delegate Methods
- (NSIndexPath *)tableView:(UITableView *)tableView
  willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    isSearching = NO;
    search.text = @"";
    
    [tableView reloadData];
    return indexPath;
}



#pragma mark -
#pragma mark Search Bar Delegate Methods
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    NSString *searchTerm = [searchBar text];
    [self handleSearchForTerm:searchTerm];
}



- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchTerm {
    if ([searchTerm length] == 0) {
        [self resetSearch]; [table reloadData];
        [self resetSearch]; [table reloadData];
        return;
    }
    else{
        
    }
    [self handleSearchForTerm:searchTerm];
}



//funtion for the cancel button
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    isSearching = NO;
    search.text = @"";
    [self resetSearch];
    [table reloadData];
    [searchBar resignFirstResponder];
}



//
- (NSInteger) tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index{
    NSString *key = [keys objectAtIndex:index];
    if (key == UITableViewIndexSearch) {
        [tableView setContentOffset:CGPointZero animated:NO]; //CGPointZero is a special constant w/c represents the point (0,0) in the coordinate system WHICH REQUIRES CORE GRAPHICS FRAMEWORK
        
        //When you build your project, if you get a link error complaining about a reference to _CGPointZero, you’ll know that Xcode did not include that framework by default, and you’ll need to add it yourself. To add this framework, go to the project navigator and select the top- level Sections item. Next, click the Build Phases tab at the top of the main pane. Then expand the Link Binary With Libraries section, click the plus button, select CoreGraphics.framework from the list that appears, and click the Add button.
        return NSNotFound;
    }
    else
        return index;
}



//The dictionary is immutable, which means we can’t add or delete values from it, and so are the arrays that it holds. We also need to retain the ability to get back to the original dataset when the user hits cancel or erases the search term. The solution is to create two dictionaries: an immutable dictionary to hold the full dataset and a mutable copy from which we can remove rows. The delegate and data sources will read from the mutable dictionary, and when the search criteria change or the search is canceled, we can refresh the mutable dictionary from the immutable one. Sounds like a plan. Let’s do it.


@end
