//
//  MainView.h
//  Chapter8_Par_3
//
//  Created by Andvari Techstars on 2/25/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainView : UIViewController <UITableViewDataSource, UITableViewDelegate>

//@property (strong, nonatomic) NSDictionary * names;
//@property (strong, nonatomic) NSArray * keys;
@property (strong, nonatomic) IBOutlet UITableView * table;
@property (strong, nonatomic) IBOutlet UISearchBar * search;

@property (strong, nonatomic) NSDictionary * allNames; //holds all the dataset
@property (strong, nonatomic) NSMutableDictionary * names; //holds the dataset that matched the current search criteria
@property (strong, nonatomic) NSMutableArray * keys; //this will hold the index values and section names
@property (assign, nonatomic) BOOL isSearching;

-(void) resetSearch;
-(void) handleSearchForTerm: (NSString *) searchTerm;

@end
