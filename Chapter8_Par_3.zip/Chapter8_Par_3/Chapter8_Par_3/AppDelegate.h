//
//  AppDelegate.h
//  Chapter8_Par_3
//
//  Created by Andvari Techstars on 2/25/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MainView;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MainView * main;

@end
