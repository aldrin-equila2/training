//
//  NSDictionary+MutableDeepCopy.m
//  Chapter8_Par_3
//
//  Created by Andvari Techstars on 2/25/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import "NSDictionary+MutableDeepCopy.h"

@implementation NSDictionary (MutableDeepCopy)

//This method creates a new mutable dictionary and then loops through all the keys of the original dictionary, making mutable copies of each array it encounters. Since this method will behave just as if it were part of NSDictionary, any reference to self is a reference to the dictionary on which this method is being called. The method first attempts to make a deep mutable copy, and if the object doesn’t respond to the mutableDeepCopy message, it tries to make a mutable copy. If the object doesn’t respond to the mutableCopy message, it falls back on making a regular copy to ensure that all the objects contained in the dictionary are copied. By doing it this way, if we were to have a dictionary that contained dictionaries (or other objects that supported deep mutable copies), the contained ones would also get deep-copied.

- (NSMutableDictionary *)mutableDeepCopy {
    NSMutableDictionary *returnDict = [[NSMutableDictionary alloc]
                                       initWithCapacity:[self count]];
    
    //for (id key in keys) --> Fast enumeration is a language-level replacement for NSEnumerator. It allows you to quickly iterate through a
    NSArray *keys = [self allKeys];
    for (id key in keys) {
        id oneValue = [self valueForKey:key];
        id oneCopy = nil;
        if ([oneValue respondsToSelector:@selector(mutableDeepCopy)])
            oneCopy = [oneValue mutableDeepCopy];
        else if ([oneValue respondsToSelector:@selector(mutableCopy)])
            oneCopy = [oneValue mutableCopy];
        if (oneCopy == nil)
            oneCopy = [oneValue copy];
        [returnDict setValue:oneCopy forKey:key];
    }
    return returnDict;
}

//If we include the NSDictionary+MutableDeepCopy.h header file in one of our other classes, we’ll be able to call mutableDeepCopy on any NSDictionary object we like. Let’s take advantage of that now.
@end
