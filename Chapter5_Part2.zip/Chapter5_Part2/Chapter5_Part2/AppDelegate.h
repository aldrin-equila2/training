//
//  AppDelegate.h
//  Chapter5_Part2
//
//  Created by Andvari Techstars on 2/20/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainView.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    MainView * main;
}
@property (strong, nonatomic) UIWindow *window;
@property (retain, nonatomic) IBOutlet MainView * main;

@end
