//
//  AppDelegate.h
//  Chapter6
//
//  Created by Andvari Techstars on 2/20/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainView;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MainView * switchViewController;

@end
