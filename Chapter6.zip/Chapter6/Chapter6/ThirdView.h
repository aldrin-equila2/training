//
//  ThirdView.h
//  Chapter6
//
//  Created by Andvari Techstars on 2/20/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdView : UIViewController

//The toolbar in the Xib is not inserted.. i have just set it in the attributes inspector of the view
-(IBAction)buttonPressed;

@end
