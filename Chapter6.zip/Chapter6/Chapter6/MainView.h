//
//  MainView.h
//  Chapter6
//
//  Created by Andvari Techstars on 2/20/14.
//  Copyright (c) 2014 Andvari Techstars. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SecondView;
@class ThirdView;

@interface MainView : UIViewController

@property (strong, nonatomic) SecondView * yellowViewController;
@property (strong, nonatomic) ThirdView * blueViewController;

-(IBAction)switchViews:(id)sender;

@end
